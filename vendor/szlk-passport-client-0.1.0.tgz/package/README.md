# @szlk/passport-client

`SZLKPassport` 的标准化服务端 SDK。

当前能力：

- `createPassportClient`
- `buildPassportHostedAuthUrl`
- `buildPassportSocialLoginUrl`
- `buildPassportGoogleLoginUrl`
- `linkIdentity`
- `lookupUser`
- `createHandoff`
- `redeemHandoff`
- `getEntitlements`
- `checkAccess`
- `getBilling`
- `getBillingCatalog`
- `createCheckoutLink`
- `getBillingCheckoutSession`
- `getBillingPortalLink`
- `createApplePurchaseIntent`
- `confirmAppleTransaction`
- `getAppleSubscription`
- `reconcileAppleSubscription`
- `registerWithPassword`
- `loginWithPassword`
- `verifyEmailToken`
- `resendVerification`
- `forgotPassword`
- `resetPassword`
- `changePassword`
- `syncLegacyUser`
- `createPassportConsumptionLayer`

默认调用 `v1` 契约，并接受旧的 `SZLK_PASSPORT_URL=https://passport.szlk.ai/api/passport` 配置格式。

`product` 已放宽为任意字符串，正式可用产品由 Passport 运行时配置决定。

Billing 入口仍保持 Passport 统一契约；当 Passport catalog 的 plan 配置了 `priceKey` 且 Passport 配置了 `CLOUDAPI_PROJECT_KEY` 时，`createCheckoutLink` 会返回 Cloudapi 创建的 Stripe Checkout Session URL。`getBillingPortalLink` 支持传 `email`、`userId` 或 `customer` 以创建动态 Stripe Customer Portal Session。

iOS 订阅也使用同一份 Passport catalog 与 entitlement：业务服务端先调用 `createApplePurchaseIntent` 取得稳定的 `appAccountToken`，App 将它传给 StoreKit；购买后业务服务端把 StoreKit 的签名交易交给 `confirmAppleTransaction`。产品始终通过 `checkAccess` 解锁，不以设备本地 StoreKit 状态另建权限真相。`reconcileAppleSubscription` 用 Apple Server API 补偿漏失通知。以上方法只允许在业务服务端调用，产品密钥不得进入 iOS App。

Headless Auth 入口用于“保留业务现有账号密码表单 UI，但把密码真相源迁到 Passport”的标准接入模式。推荐链路是：

1. 业务前端继续提交到自己的 server action 或 route handler
2. 业务服务端调用 `loginWithPassword`、`registerWithPassword`、`forgotPassword`、`resetPassword` 等方法
3. Passport 返回成功后，由业务自己建立本地 session
4. 若业务有历史本地密码用户，可用 `syncLegacyUser` 做一次性迁移桥接。旧版“一次调用即完成”语义已安全升级为 `migrationPending` 两阶段合同：首次调用发送邮箱证明并返回 `migrationPending: true`，用户取得 `verificationToken` 后再次调用才会写入密码、激活身份并返回 `migrationPending: false`。旧调用方仍可传 `emailVerified` 以保持 TypeScript 编译兼容，但 SDK 与服务端都会忽略它，绝不将其作为邮箱证明

Google/GitHub Headless 登录继续保留产品自己的 provider 按钮和本地 session，但使用 Passport OIDC code flow。产品服务端生成下游 PKCE verifier/challenge 后，用 `buildPassportSocialLoginUrl(...)` 和显式 `identityProvider` 创建统一入口；回调、身份归一化和 Passport SSO session 都由 Passport 完成。`buildPassportGoogleLoginUrl(...)` 仅作为既有 Google 调用的兼容 helper。产品兑换 OIDC code、写入最终本地用户并成功执行 `linkIdentity(...)` 后，才能创建产品 session。
